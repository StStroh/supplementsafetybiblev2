export const SUPPORT_EMAIL = "support@supplementsafetybible.com";
