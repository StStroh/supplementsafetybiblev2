export const BRAND_NAME = "Supplement Safety";
export const BRAND_NAME_FULL = "Supplement Safety Bible";
export const BRAND_TAGLINE = "Don't Mix Blind™";
